# Exercises for Java lectures

This repository contains code snippets created or used during Java lectures by [net.yetamine](http://yetamine.net/).
