package net.yetamine.lectures.language.generics;

import java.util.ArrayList;
import java.util.Collection;

public final class TestBox {

    public static void main(String... args) {
        final Box<String> stringBox = new Box<>();
        stringBox.set("something");

        final Box<Integer> integerBox = new Box<>();
        integerBox.set(1);
        System.out.println(stringBox);
        System.out.println(integerBox);

        final Collection<Number> numbers = new ArrayList<>();
        integerBox.addTo(numbers).set(10).addTo(numbers);
        System.out.println(integerBox);
        System.out.println(numbers);

        final Collection<Integer> integers = new ArrayList<>();
        integers.add(42);
        System.out.println(integerBox.takeFrom(integers));

        final Box<String> toSwap = new Box<>("swapped");
        System.out.println(stringBox.swap(toSwap));
        System.out.println(toSwap);
    }
}
