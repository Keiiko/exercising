package net.yetamine.lectures.language.inheritance.enums;

public final class TestMonth {

    public static void main(String... args) {
        System.out.println(isValidDate(29, Month.FEBRUARY, 2000));
        System.out.println(isValidDate(29, Month.FEBRUARY, 2001));
        System.out.println(isValidDate(32, Month.MARCH, 2018));
    }

    private static boolean isValidDate(int day, Month month, int year) {
        return (0 < day) && (day <= month.numberOfDays(year));
    }
}
