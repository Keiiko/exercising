module net.yetamine.playground {}
