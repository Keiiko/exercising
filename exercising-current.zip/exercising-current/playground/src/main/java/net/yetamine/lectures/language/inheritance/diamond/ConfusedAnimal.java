package net.yetamine.lectures.language.inheritance.diamond;

/**
 * Demonstrates resolving conflicting default methods by overriding with a
 * completely independent implementation.
 */
public interface ConfusedAnimal extends Cat, Dog {

    default void makeSound() {
        System.out.println("???");
    }
}
