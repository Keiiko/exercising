/**
 * Examples for exceptions.
 */
package net.yetamine.lectures.language.exceptions;
