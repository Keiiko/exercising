package net.yetamine.playground;

public final class Cat extends Animal {

    public void speak() {
        System.out.println("Meow");
    }
}
