package net.yetamine.lectures.language.inheritance.enums;

import net.yetamine.lectures.language.inheritance.Named;

/**
 * Demonstrates how an enum can be used and implemented in the complex way
 * (including constructors, fields, overriding, interface implementation).
 */
public enum DayOfWeek implements Named {

    MONDAY("Monday") {

        @Override
        public String toString() {
            return super.toString() + " (the bad day)";
        }
    },

    // @formatter:off
    TUESDAY("Tuesday"),
    WEDNESDAY("Wednesday"),
    THURSDAY("Thursday"),
    FRIDAY("Friday"),
    SATURDAY("Saturday"),
    SUNDAY("Sunday");
    // @formatter:on

    private final String name;

    DayOfWeek(String actualName) { // May be even private; but even now the compiler protects its abuse
        name = actualName;
    }

    @Override
    public String toString() {
        return name;
    }
}
