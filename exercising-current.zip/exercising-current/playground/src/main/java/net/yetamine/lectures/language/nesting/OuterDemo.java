package net.yetamine.lectures.language.nesting;

/**
 * Demonstrates the situation when the compiler is forced to generate a
 * synthetic accessors, see the warnings.
 */
public final class OuterDemo {

    public static void main(String... args) {
        final Outer hello = new Outer("Hello");
        final Outer.Inner implicit = hello.newInner();
        System.out.println(implicit);

        final Outer bye = new Outer("Bye");
        final Outer.Inner explicit = bye.new Inner(); // Explicitly qualified enclosing instance
        System.out.println(explicit);
    }
}
