package net.yetamine.lectures.language.inheritance.diamond;

/**
 * Invokes various implementations of {@link Animal} that resolve the default
 * method conflicts in different ways.
 */
public final class DefaultMethodResolution {

    public static void main(String... args) throws Exception {
        new GenericDog().makeSound();
        new SaintBernardDog().makeSound();
        new UncertainAnimal().makeSound();
        new CatMonster().makeSound();
        new SchizophrenicAnimal() {}.makeSound();
    }
}
