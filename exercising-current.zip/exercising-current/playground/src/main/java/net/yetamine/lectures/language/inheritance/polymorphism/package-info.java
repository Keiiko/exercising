/**
 * Examples of polymorphism.
 */
package net.yetamine.lectures.language.inheritance.polymorphism;
