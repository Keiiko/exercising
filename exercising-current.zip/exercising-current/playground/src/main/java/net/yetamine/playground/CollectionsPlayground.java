package net.yetamine.playground;

import java.util.ArrayList;
import java.util.List;

public class CollectionsPlayground {

    public static List<Integer> primes(int n) {
        final boolean[] numbers = new boolean[n + 1];
        final List<Integer> result = new ArrayList<>();

        for (int i = 2; i <= n; i++) {
            if (!numbers[i]) {
                result.add(i);
                for (int j = i + i; j <= n; j += i) {
                    numbers[j] = true;
                }
            }
        }

        return result;
    }

    public static void main(String... args) {
        final List<String> strings = new ArrayList<>();
        strings.add("Hello");
        final String s = strings.get(0);

        System.out.println(primes(100));

        for (Integer i : primes(100)) {
            System.out.println(i);
        }
    }
}
