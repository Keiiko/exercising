package net.yetamine.lectures.language.inheritance.diamond;

/**
 * This weird animal demonstrates resolving conflicting default methods for
 * classes, which is basically same as for interfaces.
 */
public class CatMonster implements Cat, Dog {

    public void makeSound() {
        System.out.println("GROWL!");
        System.out.println("...");
        Cat.super.makeSound();
    }
}
