/**
 * Demonstrates the difference between overriding and overloading.
 */
package net.yetamine.lectures.language.inheritance.overloading;
