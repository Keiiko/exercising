package net.yetamine.playground;

public interface Named {
    String name();
}
