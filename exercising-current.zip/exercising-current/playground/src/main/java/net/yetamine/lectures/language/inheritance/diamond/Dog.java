package net.yetamine.lectures.language.inheritance.diamond;

/**
 * An interface representing a dog.
 */
public interface Dog extends Animal {

    default void makeSound() {
        System.out.println("Woof. Woof.");
    }

    // Here we would have more methods typical for dogs, like guard()
}
