package net.yetamine.lectures.language.nesting;

/**
 * Before Java 11, which introduces the concept of nests that have access rules
 * aligned with the Java language semantics, following code produced warnings
 * because accessing private members within the enclosing type's scope as the
 * access rules implemented in JVM didn't allow that; the compiler was forced to
 * generate a synthetic accessors.
 */
public class Synthetics {

    private Private safe = new Private();

    public Insider newInsider() {
        return new Insider();
    }

    public class Insider {

        private Private safe = new Private();

        public void stealSecret() {
            // Not only violating the privacy, but also hiding the
            // enclosing scope's identifiers... so that the explicit
            // qualification is necessary for reaching the right field!
            safe.secret = Synthetics.this.safe.secret;
        }

        public int tellSecret() {
            return safe.secret;
        }
    }

    // Even private members of this class can be accessed from the
    // enclosing scope and even its siblings (like Insider)!
    private class Private {

        private int secret = 10;

        // Here, the default generated constructor is private as well!
    }
}
