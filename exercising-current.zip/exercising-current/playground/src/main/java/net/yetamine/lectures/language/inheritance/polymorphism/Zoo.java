package net.yetamine.lectures.language.inheritance.polymorphism;

/**
 * Demonstrates polymorphism and safe type casting with classes.
 */
public final class Zoo {

    public static void main(String... args) {
        final Cat myCat = new Cat();
        myCat.introduceSelf();
        final Dog myDog = new Dog();
        myDog.introduceSelf();

        final Animal[] zoo = { myCat, myDog };
        for (int animalIndex = 0; animalIndex < zoo.length; animalIndex++) {
            final Animal animal = zoo[animalIndex];
            animal.makeSound();
            animal.introduceSelf();

            if (animal instanceof Dog) {
                final Dog dog = (Dog) animal;
                dog.watch();
            }
        }
    }
}
