package net.yetamine.lectures.language.packages.internal;

/**
 * Demonstrates what a class can use from the same package.
 */
public final class Spy {

    public static void tellSecret() {
        Visible.printPackagePrivate();
        Visible.printProtected();
        //System.out.println(Internal.TOP_SECRET); // Not compilable with private TOP_SECRET
    }
}
