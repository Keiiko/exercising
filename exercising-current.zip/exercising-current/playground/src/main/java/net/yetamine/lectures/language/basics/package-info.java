/**
 * Examples and samples for language basics and syntactic constructs. Because
 * the examples are simplified, the classes usually lack some details that they
 * should have, e.g., being declared as final.
 */
package net.yetamine.lectures.language.basics;
