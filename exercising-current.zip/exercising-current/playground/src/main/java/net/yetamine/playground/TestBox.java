package net.yetamine.playground;

import java.util.ArrayList;
import java.util.List;

public class TestBox {
    public static void main(String... args) {
        final Box<String> myBox = new Box<>();
        System.out.println(myBox.get());
        myBox.set("Hello");
        System.out.println(myBox.get());

        final Box<String> anotherBox = new Box<>();
        anotherBox.set("Hello");

        System.out.println(myBox.equals(anotherBox));
        System.out.println(myBox);
        System.out.println(new Box<>());

        final List<String> strings = new ArrayList<>();
        myBox.addTo(strings);
        myBox.takeFrom(strings);

        final List<Object> objects = new ArrayList<>();
        myBox.addTo(objects);

        final Box<Number> numberBox = new Box<>();
        final List<Integer> integers = new ArrayList<>();
        numberBox.takeFrom(integers);
    }
}
