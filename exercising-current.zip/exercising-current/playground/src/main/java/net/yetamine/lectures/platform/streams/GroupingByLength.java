package net.yetamine.lectures.platform.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Demonstrates the incremental evolution of a simple algorithm using more and
 * more advanced techniques.
 */
@SuppressWarnings("unused")
public final class GroupingByLength {

    public static void main(String... args) {
        final Collection<String> strings = new ArrayList<>(Arrays.asList("Hello", "Dolly", "Friday", "I", "Robot"));
        final SortedMap<Integer, Set<String>> stringsByLength = groupByLengthWithStreams(strings);
        System.out.println(stringsByLength);
    }

    private static SortedMap<Integer, Set<String>> groupByLengthWithStreams(Collection<String> strings) {
        return strings.stream().collect(Collectors.groupingBy(String::length, TreeMap::new, Collectors.toSet()));
    }

    private static SortedMap<Integer, Set<String>> groupByLengthWithLambdas(Collection<String> strings) {
        final SortedMap<Integer, Set<String>> result = new TreeMap<>();
        strings.forEach(string -> result.computeIfAbsent(string.length(), length -> new HashSet<>()).add(string));
        return result;
    }

    private static SortedMap<Integer, Set<String>> groupByLengthUsingMapEffectively(Collection<String> strings) {
        final SortedMap<Integer, Set<String>> result = new TreeMap<>();

        for (String string : strings) {
            result.computeIfAbsent(string.length(), length -> new HashSet<>()).add(string);

//            result.computeIfAbsent(string.length(), new Function<Integer, Set<String>>() {
//                public Set<String> apply(Integer t) {
//                    return new HashSet<>();
//                }
//            }).add(string);
        }

        return result;
    }

    private static SortedMap<Integer, Set<String>> groupByLengthImproved(Collection<String> strings) {
        final SortedMap<Integer, Set<String>> result = new TreeMap<>();

        for (String string : strings) {
            final Integer length = string.length();

            Set<String> stringsWithTheLength = result.get(length);
            if (stringsWithTheLength == null) {
                stringsWithTheLength = new HashSet<>();
                result.put(length, stringsWithTheLength);
            }

            stringsWithTheLength.add(string);
        }

        return result;
    }

    private static SortedMap<Integer, Set<String>> groupByLengthFirstTry(Collection<String> strings) {
        final SortedMap<Integer, Set<String>> result = new TreeMap<>();

        for (String string : strings) {
            final int length = string.length();

            final Set<String> stringsWithTheLength = result.get(length);
            if (stringsWithTheLength != null) {
                stringsWithTheLength.add(string);
            } else {
                final Set<String> newGroup = new HashSet<>();
                newGroup.add(string);
                result.put(length, newGroup);
            }
        }

        return result;
    }
}
