/**
 * Examples explaining functional interfaces and lambdas.
 */
package net.yetamine.lectures.language.lambda;
