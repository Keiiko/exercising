package net.yetamine.lectures.language.inheritance.overloading;

/**
 * An overloading demonstration.
 */
public final class InheritedOverloading {

    public static void main(String... args) {
        final Dog dog = new Dog();
        dog.bark();
        dog.bark(3);
        dog.bark("WOOF!");
        dog.bark("Woof?", 2);

        final WatchDog watcher = new WatchDog();
        watcher.bark(1, "Swap");
        watcher.bark("Which?", 1);
        watcher.bark((Object) "Which?", 1);
    }
}
