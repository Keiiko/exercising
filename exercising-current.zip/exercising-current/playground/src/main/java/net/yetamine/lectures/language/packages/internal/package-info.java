/**
 * A package containing a few package-private parts that serve for demonstration
 * of the default access.
 */
package net.yetamine.lectures.language.packages.internal;
