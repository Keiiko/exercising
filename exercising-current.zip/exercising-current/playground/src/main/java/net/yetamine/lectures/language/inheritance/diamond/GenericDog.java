package net.yetamine.lectures.language.inheritance.diamond;

/**
 * An immediately usable generic dog implementation that uses the default
 * implementation.
 */
public class GenericDog implements Dog {
    // If any other method needed implementation, it would be here
}
