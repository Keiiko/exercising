package net.yetamine.lectures.platform.time;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Shows briefly the legacy {@link Date} and the new Date/Time API and the
 * bridge between them.
 */
public final class DateTimeExamples {

    public static void main(String... args) throws Exception {
        final Date date = new Date();
        System.out.println(date);
        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        System.out.println(calendar.get(Calendar.HOUR));
        calendar.setTimeZone(TimeZone.getTimeZone("GMT+1"));
        System.out.println(calendar.get(Calendar.HOUR));
        final DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mmZ");
        System.out.println(format.format(date));

        final Instant instant = date.toInstant();
        final ZonedDateTime zonedDateTime = instant.atZone(ZoneId.of("GMT+1"));
        System.out.println(zonedDateTime);
        System.out.println(zonedDateTime.truncatedTo(ChronoUnit.MINUTES));
        final LocalTime localTime = zonedDateTime.toLocalTime();
        System.out.println(localTime.plusHours(23));
        System.out.println(localTime.format(DateTimeFormatter.ofPattern("HH:mm")));
        final LocalTime truncatedTime = localTime.truncatedTo(ChronoUnit.MINUTES).with(time -> {
            final long minute = ChronoField.MINUTE_OF_HOUR.getFrom(time);
            final long truncated = minute - (minute % 15);
            return time.with(ChronoField.MINUTE_OF_HOUR, truncated);
        });

        System.out.println(truncatedTime);

        // Clock for testing
        final Instant fixed = Instant.parse("2018-07-22T12:30:00Z");
        final Clock clock = Clock.fixed(fixed, ZoneId.of("UTC"));
        System.out.println(clock.instant());

        final Duration offset = Duration.ofNanos(Clock.systemUTC().instant().until(fixed, ChronoUnit.NANOS));
        System.out.println(offset);
        final Clock testClock = Clock.offset(Clock.systemUTC(), offset);
        System.out.println(testClock.instant());
        Thread.sleep(1000);
        System.out.println(testClock.instant());
        Thread.sleep(1000);
        System.out.println(testClock.instant());

        System.out.println(fixed.atZone(ZoneId.of("UTC")).plus(Period.ofMonths(2).plusDays(10)));
    }
}
