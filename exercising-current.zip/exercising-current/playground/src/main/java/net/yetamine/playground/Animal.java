package net.yetamine.playground;

public abstract class Animal {

    public abstract void speak();
}
