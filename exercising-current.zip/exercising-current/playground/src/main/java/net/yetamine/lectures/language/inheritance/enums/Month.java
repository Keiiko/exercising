package net.yetamine.lectures.language.inheritance.enums;

import net.yetamine.lectures.language.inheritance.Named;

/**
 * Another enum example.
 */
public enum Month implements Named {

    JANUARY("January", 31), ///

    FEBRUARY("February", 28) {

        @Override
        public int numberOfDays(int year) {
            return isLeap(year) ? super.numberOfDays(year) + 1 : super.numberOfDays(year);
        }

        private boolean isLeap(int year) {
            if (year % 4 != 0) {
                return false;
            }
            // Somewhat incorrect for years before 1582 (introduction of Gregorian calendar);
            // even more incorrect for years BC, astronomical calendar must be used then
            if ((year % 100 != 0) || (year % 400 == 0)) {
                return true;
            }

            return false;
        }
    },

    // @formatter:off
    MARCH("March", 31),
    APRIL("April", 30),
    MAY("May", 31),
    JUNE("June", 30),
    JULY("July", 31),
    AUGUST("August", 31),
    SEPTEMBER("August", 30),
    OCTOBER("October", 31),
    NOVEMBER("November", 30),
    DECEMBER("December", 31);
    // @formatter:on

    private final String name;
    private final int numberOfDays;

    private Month(String displayedName, int length) {
        numberOfDays = length;
        name = displayedName;
    }

    @Override
    public String toString() {
        return name;
    }

    public int numberOfDays(int year) {
        return numberOfDays;
    }
}
