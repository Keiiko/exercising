package net.yetamine.playground;

import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;

public final class Box<T> {

    private T data;

    public Box() {
        // Default constructor
    }

    public T get() {
        return data;
    }

    public void set(T data) {
        this.data = data;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Box) {
            final Box<?> o = (Box<?>) obj;
//            return ((data == o.data) || ((data != null) && data.equals(o.data)));
            return Objects.equals(data, o.data);
        }

        return false;
    }

    @Override
    public int hashCode() {
//        return (data == null) ? 0 : data.hashCode();
        return Objects.hashCode(data);
    }

    @Override
    public String toString() {
        return (data == null) ? "[]" : "[" + data + "]";
    }

    public void addTo(Collection<? super T> collection) {
        if (data != null) {
            collection.add(data);
        }
    }

    public void takeFrom(Collection<? extends T> collection) {
        final Iterator<? extends T> it = collection.iterator();
        final T value = it.next();
        it.remove();
        data = value;
    }
}
