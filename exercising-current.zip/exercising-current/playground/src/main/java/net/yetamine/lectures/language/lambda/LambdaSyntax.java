package net.yetamine.lectures.language.lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Demonstrates the lambda syntax.
 */
public final class LambdaSyntax {

    /**
     * A home-made version of {@link java.util.function.ToIntFunction} (assuming
     * this was available earlier).
     *
     * <p>
     * There is only one method required to be implemented, such an interface is
     * called <em>functional</em> and can be used for lamda expressions.
     *
     * @param <T>
     *            the type of argument
     */
    private interface ToIntFunction<T> {

        /**
         * Applies this function to the given argument.
         *
         * @param value
         *            the function argument
         *
         * @return the function result
         */
        int apply(T value);
    }

    private static <T> void printComputed(Iterable<? extends T> values, ToIntFunction<T> f) {
        for (T value : values) {
            System.out.format("%s -> %d%n", value, f.apply(value));
        }
    }

    public static void main(String... args) throws Exception {
        final Collection<String> values = Arrays.asList("one", "two", "three", "");

        // Traditional usage before Java 8: no lambda
        final ToIntFunction<String> length = new ToIntFunction<String>() {

            public int apply(String value) {
                return value.length();
            }
        };

        printComputed(values, length);

        // Traditional usage before Java 8: no lambda, just more compact form
        printComputed(values, new ToIntFunction<String>() {

            public int apply(String value) {
                return value.length();
            }
        });

        // Java 8: explicitly defined lambda in various ways
        final ToIntFunction<String> lambda1 = (final String s) -> {
            return s.length();
        };
        printComputed(values, lambda1);

        final ToIntFunction<String> lambda2 = (String s) -> s.length();
        printComputed(values, lambda2);

        final ToIntFunction<String> lambda3 = s -> s.length();
        printComputed(values, lambda3);

        final ToIntFunction<String> lambda4 = String::length;
        printComputed(values, lambda4);

        final ToIntFunction<Object> lambda5 = o -> 42;
        printComputed(values, lambda5);

        // For completeness of the syntax demonstration
        final Callable<Integer> parameterless = () -> 42;
        System.out.println(parameterless.call());

        // Java8: implicitly defined lambda as above
        printComputed(values, (final String s) -> {
            return s.length();
        });

        printComputed(values, (String s) -> s.length());
        printComputed(values, s -> s.length());
        printComputed(values, String::length);
        printComputed(values, o -> 42);

        // There is more about lambdas

        // Lambda body can be quite complex and use whatever a normal function can
        printComputed(values, s -> {
            int result = 0;
            for (int i = s.length(); i-- > 0;) {
                ++result;
            }

            return result;
        });

        // Lambda body can use variables of the enclosing scope
        final int someFinalValue = 42; // Here could be a complex calculation
        printComputed(values, o -> someFinalValue);

        // The variable needn't be declared final, but it must be effectively final
        int someVariable = someFinalValue + 1;
        printComputed(values, o -> someVariable);
        // someVariable = 1; // FIXME: Such a change is not allowed then!

        // We already know this:
        //
        // final ToIntFunction<String> length = String::length;
        ///
        // But we can use even a constructor! This is how a factory can be made easily.
        final Supplier<Collection<Number>> factory = HashSet::new;

        final Collection<Number> c1 = factory.get();
        c1.add(Math.PI);
        c1.add(1);

        final Collection<Number> c2 = factory.get();
        c2.add(2);

        // These are really diffent
        System.out.println(c1);
        System.out.println(c2);

        // With conversion constructors, it is easy to duplicate or convert objects
        // even without the flawed infamous Cloneable interface
        final Function<Collection<? extends Number>, List<Number>> convertToList = ArrayList<Number>::new;

        final Set<Integer> set = Collections.singleton(42);
        final List<Number> list = convertToList.apply(set);
        list.add(Math.PI);
        System.out.println(set);
        System.out.println(list);

        // Lambda is a polyexpression: the same code is coerced to the context
        final Function<String, Integer> f = String::length;
        System.out.println(f.apply("string"));

        // A lambda can "return" another lambda
        // For the clarity, let's fill the parens around the "returned" lambda
        final Callable<Runnable> callable = () -> (() -> System.out.println("Hello from a Runnable."));
        callable.call().run();

        // A constant function returning a lambda (and now already without the parens as usual)
        final Function<String, Runnable> bind = s -> () -> System.out.println(s);
        final Runnable bound = bind.apply("Hello from a bound Runnable.");
        bound.run();

        // It can be used even for binding arguments in a way
        final Function<String, Consumer<? super String>> hello = s -> t -> System.out.println(s);
        final Function<String, Consumer<? super String>> world = s -> t -> System.out.println(t);
        final Function<String, Consumer<? super String>> whole = s -> t -> System.out.println(s + " " + t);
        hello.apply("Hello").accept("World");
        world.apply("Hello").accept("World");
        whole.apply("Hello").accept("World");
    }
}
