package net.yetamine.playground;

public class Equality {
    public static void main(String... args) {
        final Dog alik1 = new Dog("Alik");
        final Dog alik2 = new Dog("Alik");
        System.out.println(alik1 == alik2);
        System.out.println(alik1.equals(alik2));
        System.out.println(alik1);
    }
}
