package net.yetamine.lectures.language.inheritance.polymorphism;

import net.yetamine.lectures.language.inheritance.Named;
import net.yetamine.lectures.language.inheritance.enums.DayOfWeek;

/**
 * Demonstrates polymorphism with both classes and interfaces.
 */
public final class Mixed {

    public static void main(String... args) {
        final Car roadster = new Car("Ferrari", 150);
        final Car mini = new Car("Mini Cooper", 30);
        roadster.go(); // (Almost) non-virtual call
        mini.go();

        final Named[] namedThings = { roadster, mini, new Dog(), DayOfWeek.MONDAY };
        for (int index = 0; index < namedThings.length; index++) {
            final Named thing = namedThings[index];
            System.out.println(thing.name());
        }
    }
}
