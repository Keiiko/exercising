/**
 * Demonstrates the inheritance possibilities with enums.
 */
package net.yetamine.lectures.language.inheritance.enums;
