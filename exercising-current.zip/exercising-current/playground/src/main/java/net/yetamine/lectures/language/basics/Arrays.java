package net.yetamine.lectures.language.basics;

import java.util.Comparator;

/**
 * Shows a few examples how arrays can be used.
 */
public class Arrays {

    public static void main(String[] args) {
        int[] ints = { 10, 20, 30 };
        print(ints);

        System.out.println("--- Filling and incrementing");

        ints = fill(40, 5);
        print(ints);
        increment(ints);
        print(ints);

        System.out.println("--- Reversing");

        ints = new int[0];
        int[] reversed = reversed(ints);
        print(reversed);

        ints = new int[] { 1 };
        reversed = reversed(ints);
        print(reversed);

        ints = new int[] { 1, 2 };
        reversed = reversed(ints);
        print(reversed);

        ints = new int[] { 1, 2, 3 };
        reversed = reversed(ints);
        print(reversed);

        ints = new int[] { 1, 2, 3, 4, 5 };
        reversed = reversed(ints);
        print(reversed);

        System.out.println("--- Reversing in place");

        ints = new int[] {};
        reversed = reverse(ints);
        print(reversed);

        ints = new int[] { 1 };
        reversed = reverse(ints);
        print(reversed);

        ints = new int[] { 1, 2 };
        reversed = reverse(ints);
        print(reversed);

        ints = new int[] { 1, 2, 3 };
        reversed = reverse(ints);
        print(reversed);

        ints = new int[] { 1, 2, 3, 4, 5 };
        reversed = reverse(ints);
        print(reversed);

        System.out.println("--- 2D");

        int[][] ints2d = { { 1, 2, 3 }, { 4, 5 }, { 6, 7, 8 } };

        System.out.println(ints2d[2]); // Prints, but what?

//        System.out.println(Arrays.toString(array2d[0])); // A built-in alternative
        for (int rowIndex = 0; rowIndex < ints2d.length; rowIndex++) {
            printRow(ints2d[rowIndex]);
        }

        System.out.println("--- Using for-each loop");

        final Integer[] array = { 2, 3, 1, 0 };

        java.util.Arrays.sort(array); // An example of resolving name conflict
        for (int element : array) {
            System.out.println(element);
        }

        final String[] strings = { "Hello", "Dolly", "Jane" };
        java.util.Arrays.sort(strings, Comparator.reverseOrder());
        System.out.println(java.util.Arrays.toString(strings));
    }

    private static void increment(int[] ints) {
        for (int i = 0; i < ints.length; i++) {
            ++ints[i];
        }
    }

    private static int[] fill(int value, int count) {
        int[] result = new int[count];
        for (int i = 0; i < count; i++) {
            result[i] = value;
        }

        return result;
    }

    private static int[] reversed(int[] array) {
        int[] result = new int[array.length];
        for (int source = array.length - 1, target = 0; 0 <= source; source--, target++) {
            result[target] = array[source];
        }

        // Alternative implementation #1
//        for (int source = 0, target = result.length - 1; source < array.length; source++, target--) {
//            result[target] = array[source];
//        }

        // Alternative implementation #2
//        for (int source = 0; source < array.length; source++) {
//            int target = result.length - 1 - source;
//            result[target] = array[source];
//        }

        return result;
    }

    private static int[] reverse(int[] array) {
        for (int source = array.length - 1, target = 0; target < source; source--, target++) {
            int temp = array[source];
            array[source] = array[target];
            array[target] = temp;
        }

        return array;
    }

    private static void print(int[] ints) {
        for (int i = 0; i < ints.length; i++) {
            System.out.format("%d ", ints[i]);
        }

        System.out.println();
    }

    private static void printRow(int[] array) {
        for (int index = 0; index < array.length; index++) {
            System.out.print(array[index] + " ");
        }

        System.out.println();
    }
}
