package net.yetamine.lectures.language.nesting;

/**
 * Demonstrates the relationship between an outer class and an inner non-static
 * class.
 */
public class Outer {

    private final String message;

    public Outer(String givenMessage) {
        message = givenMessage;
    }

    public Inner newInner() {
        return new Inner(); // Implicitly used this as the enclosing instance for the new Inner
    }

    public class Inner {

        public Inner() {
            // Default constructor
        }

        @Override
        public String toString() {
            return message;
        }
    }
}
