package net.yetamine.lectures.language.basics;

/**
 * Demonstrates of the most basic constructs that the language provides. For
 * instance, this is a documentation comment.
 */
public class SyntaxStarter {

    // A single-line comment

    /*
     * A
     * multiline
     * comment
     */

    public static void main(String[] args) {
        int i = 10;
        if (i == 10) {
            int j = 20;
            System.out.println(j);
        } else {
            // Not possible to refer to j here
            System.out.println(i);
        }

        {
            int j = 30;
            System.out.println(j);

            {
                // Not possible to hide a local variable with some other
                // int j = 20;
            }
        }

        // Not possible to refer to j here, out of the declaring block
        // System.out.println(j);

        // What does this print?
        i = 1;
        System.out.println(i++ + ++i);
        // Well, this is well-defined in Java, but rather don't do that

        // Let's test some literals
        char b = 'a' + 1;
        System.out.println(b);

        i = 0xDEAD_BEEF;
        i += 0b101_1111;
        i += 'a';
        char a = (char) i; // Type cast necessary
        System.out.println(a);

        // String concatenation and special characters
        System.out.println("Special chars: \b\f\n\r\t\"\'\u0031" + '"');
        float pi = 3.14f; // Either cast or use the -f suffix
        System.out.println(pi);

        String s = "a"; // Change to test other cases
        switch (s) {
            default:
                System.out.println("Default");
                // Fallthrough

            case "A":
                System.out.println("A");
                break;

            case "B":
                System.out.println("B");
                break;
        }
    }
}
