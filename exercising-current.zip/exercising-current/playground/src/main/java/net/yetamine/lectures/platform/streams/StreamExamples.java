package net.yetamine.lectures.platform.streams;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * More complex examples of using streams, rather to demonstrate the power of
 * streams.
 */
public final class StreamExamples {

    public static void main(String... args) {
        complexProcessing();
        frequencyAnalysis();
        printingRandoms();
        findingEvenOne();
        generatingFibonacci();
        generatingBigFibonacci();
        filterVowels();
        mostlyVowels();
    }

    /**
     * Sorts all non-empty strings in reversed order by length, and equally long
     * strings sort naturally (in lexicographical order), finally stores top 4
     * items in a list that is printed.
     */
    private static void complexProcessing() {
        System.out.println(":: Complex processing");
        final List<String> strings = Arrays.asList("Hello", "Dolly", "I", "Robot", "", "Jane", "Eyer", "Pinocchio");

        // @formatter:off
        final List<String> nonEmpty = strings.stream()
                .filter(s -> !s.isEmpty())
                .sorted(Comparator.comparing(String::length).reversed().thenComparing(Comparator.naturalOrder()))
                .limit(4)
                .collect(Collectors.toList());
        // @formatter:on

        System.out.println(nonEmpty);

        { // Java 7 code
            final List<String> temporary = new ArrayList<>();
            for (String string : strings) {
                if (!string.isEmpty()) {
                    temporary.add(string);
                }
            }

            Collections.sort(temporary, new Comparator<String>() {

                public int compare(String o1, String o2) {
                    final int result = Integer.compare(o2.length(), o1.length());
                    return (result != 0) ? result : o1.compareTo(o2);
                }
            });

            final List<String> desired = new ArrayList<>(temporary.subList(0, Math.min(temporary.size(), 4)));
            System.out.println(desired);
        }
    }

    /**
     * Splits a string and wraps the array into a stream which performs
     * frequency analysis: it counts the occurrences of each word from the
     * stream prints them in a sorted way.
     */
    private static void frequencyAnalysis() {
        System.out.println(":: Frequency analysis");

        // @formatter:off
        final Map<String, Long> grouping = Stream.of("What do you read, my lord? Words, words, words.".split("[.,?; ]"))
                .filter(s -> !s.isEmpty())
                .map(String::toLowerCase)
                .collect(Collectors.groupingBy(Function.identity(), TreeMap::new, Collectors.counting()));
        // @formatter:on

        System.out.println(grouping);
    }

    /**
     * Prints five sorted random numbers in the same way as collections are
     * displayed using {@link IntStream}.
     */
    private static void printingRandoms() {
        System.out.println(":: Randoms");

        // @formatter:off
        System.out.println(
            new Random()
                .ints(0, 10)
                .map(i -> i * i)
                .distinct()
                .limit(5)
                .sorted()
                .mapToObj(Integer::toString)
                .collect(Collectors.joining(", ", "[", "]"))
        );
        // @formatter:on
    }

    /**
     * Uses {@link Stream#findAny()} to get an {@link Optional}, which is used
     * to convert the value to a string (if any value found), or to supply an
     * alternative result.
     */
    private static void findingEvenOne() {
        System.out.println(":: Finding even one");

        // @formatter:off
        System.out.println(
            IntStream.of(1, 2, 3, 4, 5)
                .filter(i -> i % 2 == 0)
                .boxed().findAny()
                .map(i -> i.toString())
                .orElse("N/A")
        );
        // @formatter:on
    }

    /**
     * Generates Fibonnaci's sequence with streams.
     */
    private static void generatingFibonacci() {
        System.out.println(":: Fibonacci");

        // A small trick of using { 1, 0 } is used here to include the leading 0
        Stream.iterate(new long[] { 1, 0 }, state -> 0 <= state[1], state -> {
            final long next = state[0] + state[1];
            state[0] = state[1];
            state[1] = next;
            return state;
        }).mapToLong(state -> state[1]).forEach(System.out::println);
    }

    /**
     * Generates Fibonnaci's sequence with streams and {@link BigInteger}.
     */
    private static void generatingBigFibonacci() {
        System.out.println(":: Big Fibonacci");

        // A small trick of using { 1, 0 } is used here to include the leading 0
        Stream.iterate(new BigInteger[] { BigInteger.ONE, BigInteger.ZERO }, state -> {
            final BigInteger next = state[0].add(state[1]);
            state[0] = state[1];
            state[1] = next;
            return state;
        }).map(state -> state[1]).limit(100).forEach(System.out::println);
    }

    /**
     * Filters vowels from a text.
     */
    private static void filterVowels() {
        System.out.println(":: Filter vowels");

        // @formatter:off
        System.out.println(
            "What do you read, my lord? Words, words, words.".chars()
                .filter(c -> !isVowel(c))
                .collect(StringBuilder::new, (s, c) -> s.append((char) c), StringBuilder::append)
                .toString()
        );
        // @formatter:on
    }

    /**
     * Finds words consisting mostly of vowels.
     */
    private static void mostlyVowels() {
        System.out.println(":: Mostly vowels");

        // @formatter:off
        Stream.of("one", "two", "three", "five", "eleven")
            // Rounding trick (otherwise compare total - vowels <= vowels)
            .filter(s -> (s.length() + 1) / 2 <= countVowels(s))
            .forEach(System.out::println);
        // @formatter:on
    }

    private static int countVowels(String s) {
        return (int) s.chars().filter(StreamExamples::isVowel).count();
    }

    private static boolean isVowel(int c) {
        switch (Character.toLowerCase(c)) {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                return true;

            default:
                return false;
        }
    }
}
