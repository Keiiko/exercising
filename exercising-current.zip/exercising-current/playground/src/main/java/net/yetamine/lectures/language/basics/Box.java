package net.yetamine.lectures.language.basics;

/**
 * A simple (non-generic) value boxing class.
 */
public class Box {

    private int value;

    public Box() {
        // Default constructor
    }

    public Box(int number) {
        value = number;
    }

    public int value() {
        return value;
    }

    public void value(int replacement) {
        value = replacement;
    }

    // TODO: Improve as much as you can
    //
    // Hints:
    // - Override some inherited methods
    // - Make the class final
}
