/**
 * Examples and samples for Collections API with various levels of using
 * lambdas.
 */
package net.yetamine.lectures.platform.collections;
