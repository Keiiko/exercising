package net.yetamine.lectures.language.inheritance.polymorphism;

import net.yetamine.lectures.language.inheritance.Named;

/**
 * An example of an independent interface implementation.
 */
public class Car implements Named {

    private final int speed;
    private final String name;

    public Car(String givenName, int maxSpeed) {
        speed = maxSpeed;
        name = givenName;
    }

    public String name() {
        return name;
    }

    public void go() {
        System.out.println("Driving at " + speed + " mph!");
    }
}
