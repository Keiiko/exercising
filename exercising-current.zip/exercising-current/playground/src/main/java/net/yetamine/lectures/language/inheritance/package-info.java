/**
 * Examples for inheritance.
 */
package net.yetamine.lectures.language.inheritance;
