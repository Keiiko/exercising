package net.yetamine.lectures.language.inheritance.polymorphism;

import net.yetamine.lectures.language.inheritance.Named;

/**
 * An example of an abstract class and implementation of an interface.
 */
public abstract class Animal implements Named {

    private final String name;

    protected Animal(String givenName) {
        name = givenName;
    }

    public String name() {
        return name;
    }

    public final void introduceSelf() {
        System.out.println("Hello, I'm " + name);
    }

    public abstract void makeSound();
}
