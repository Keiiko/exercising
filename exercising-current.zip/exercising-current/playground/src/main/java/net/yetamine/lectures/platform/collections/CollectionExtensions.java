package net.yetamine.lectures.platform.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public final class CollectionExtensions {

    public static void main(String... args) {
        final int limit = Integer.valueOf(args[0]);

        { // Lambda in action
            final List<String> strings = new ArrayList<>(Arrays.asList("Hello", "Dolly", "I", "Robot", "Jane", "Eyer"));
            final Map<Integer, Set<String>> lengths = new TreeMap<>();
            strings.forEach(s -> lengths.computeIfAbsent(s.length(), l -> new HashSet<>()).add(s));
            lengths.forEach((length, items) -> System.out.format("%s = %s%n", length, items));
            strings.removeIf(s -> s.length() > limit);
            strings.forEach(System.out::println);
        }

        { // Java 7 code
            final List<String> strings = new ArrayList<>(Arrays.asList("Hello", "Dolly", "I", "Robot", "Jane", "Eyer"));
            final Map<Integer, Set<String>> lengths = new TreeMap<>();
            for (String s : strings) {
                final Integer length = s.length();
                Set<String> items = lengths.get(length);
                if (items == null) {
                    items = new HashSet<>();
                }

                lengths.put(length, items);
                items.add(s);
            }

            for (Map.Entry<Integer, Set<String>> entry : lengths.entrySet()) {
                System.out.format("%s = %s%n", entry.getKey(), entry.getValue());
            }

            for (Iterator<String> it = strings.iterator(); it.hasNext();) {
                if (it.next().length() > limit) {
                    it.remove();
                }
            }

            for (String s : strings) {
                System.out.println(s);
            }
        }
    }
}
