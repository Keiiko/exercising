/**
 * Demonstrates the diamond problem, which is actually not a problem for Java
 * with interfaces.
 */
package net.yetamine.lectures.language.inheritance.diamond;
