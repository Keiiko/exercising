package net.yetamine.lectures.language.inheritance.polymorphism;

/**
 * A concrete {@link Animal}.
 */
public class Cat extends Animal {

    public Cat() {
        super("Mici");
    }

    public void makeSound() {
        System.out.println("Meow");
    }
}
