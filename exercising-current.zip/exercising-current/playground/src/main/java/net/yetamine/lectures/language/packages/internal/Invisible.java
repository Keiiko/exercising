package net.yetamine.lectures.language.packages.internal;

/**
 * A class invisible outside of its package.
 */
final class Invisible {

    public static void publish() {
        System.out.println("Invisible::publish");
    }
}
