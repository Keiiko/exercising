package net.yetamine.playground;

public class Primes {
    public static void main(String... args) {
        int n = 20;

        if (n < 2) {
            System.out.println("No");
            return;
        }

        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                System.out.println("No");
                return;
            }
        }

        System.out.println("Yes");
    }
}
