package net.yetamine.lectures.language.inheritance.diamond;

/**
 * Demonstrates that there is no problem with implementing an interface that
 * already resolved the default method conflict.
 */
public class UncertainAnimal implements HybridAnimal {

    public void makeSound() {
        System.out.println("I don't know what I am.");
    }
}
