package net.yetamine.lectures.language.packages;

import net.yetamine.lectures.language.packages.internal.Spy;
import net.yetamine.lectures.language.packages.internal.Visible;

/**
 * An attempt to abuse visible parts of a package, especially {@link Visible}
 * that should have been final or should have no dangerous protected methods.
 */
public final class AbusingVisible extends Visible {

    public static void main(String... args) {
        Visible.printPublic();
        //Internal.printPackagePrivate();
        Spy.tellSecret();

        Visible.printProtected(); // Oops. This might not be expected!
    }
}
