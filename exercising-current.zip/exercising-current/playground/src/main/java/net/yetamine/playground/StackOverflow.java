package net.yetamine.playground;

public class StackOverflow {
    public static void main(String... args) {
        main(args);
    }
}
