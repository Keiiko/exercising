package net.yetamine.lectures.language.generics;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Demonstrates using wildcards (remember PECS).
 */
public final class Wildcards {

    public static void main(String... args) {
        final List<String> strings = new ArrayList<>();
        fill(strings, "|-|", 10);
        print(strings);

        final List<Integer> integers = new ArrayList<>();
        fill(integers, 1, 10);
        print(integers);

        final List<Double> doubles = new ArrayList<>();
        fill(doubles, 2.0, 10);
        print(doubles);

        System.out.println(sum(integers));
        System.out.println(sum(doubles));

        final List<Number> numbers = new ArrayList<>();
        copy(integers, numbers, 5);
        copy(doubles, numbers, 5);
        System.out.println(sum(numbers));

        final Set<Number> copied = addAll(integers, new HashSet<>());
        System.out.println(copied);

        final List<String> words = Arrays.asList("Hello", "Dolly"); // Could be even List<?>
        swap(words, 0, 1);
        System.out.println(words);
    }

    // Here collection consumes, so it must be <? super T>
    public static <T> void fill(Collection<? super T> collection, T element, int count) {
        for (int i = 0; i < count; i++) {
            collection.add(element);
        }
    }

    // Here the iterable produces anything, so it can be just <?>
    public static void print(Iterable<?> iterable) {
        for (Object element : iterable) {
            System.out.println(element);
        }
    }

    // Here the collection produces, but numbers, therefore bounded <? extends Number>
    public static BigDecimal sum(Collection<? extends Number> numbers) {
        BigDecimal result = BigDecimal.ZERO;
        for (Number number : numbers) {
            try {
                result = result.add(new BigDecimal(number.toString()));
            } catch (NumberFormatException e) {
                throw new ArithmeticException(String.format("Could not add %s.", number));
            }
        }

        return result;
    }

    // Both wildcards in action for both positions
    public static <T> void copy(Iterable<? extends T> source, Collection<? super T> target, int count) {
        int copied = 0;
        for (T element : source) {
            if (count <= copied) {
                break;
            }

            target.add(element);
        }
    }

    // A more complex wildcard for a type parameter bounded by another type parameter
    public static <T, C extends Collection<? super T>> C addAll(Iterable<? extends T> source, C target) {
        for (T element : source) {
            target.add(element);
        }

        return target;
    }

    // Demonstrates capturing the wildcard capture
    public static void swap(List<?> list, int index1, int index2) {
        swap0(list, index1, index2);
    }

    private static <T> void swap0(List<T> list, int index1, int index2) {
        final T temp = list.get(index1);
        list.set(index1, list.get(index2));
        list.set(index2, temp);
    }
}
