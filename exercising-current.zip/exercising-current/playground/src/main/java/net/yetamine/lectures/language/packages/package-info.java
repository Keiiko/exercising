/**
 * Contains an exercise to explain Java packages.
 */
package net.yetamine.lectures.language.packages;
