package net.yetamine.lectures.language.inheritance.diamond;

/**
 * Demonstrates overriding a default method in a class.
 */
public class SaintBernardDog implements Dog {

    public void makeSound() {
        System.out.println("WOOF... WOOF... WOOF WOOF WOOF!");
    }
}
