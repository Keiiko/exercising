package net.yetamine.lectures.language.basics;

/**
 * Prints a triangle with different loops.
 */
public class Loops {

    public static void main(String[] args) {
        // For loop
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.format("%d ", j);
            }

            System.out.println();
        }

        System.out.println();

        // While loop
        int i = 0;
        while (i < 10) {
            int j = 0;
            while (j <= i) {
                System.out.format("%d ", j++);
            }

            System.out.println();
            ++i;
        }

        System.out.println();
    }
}
