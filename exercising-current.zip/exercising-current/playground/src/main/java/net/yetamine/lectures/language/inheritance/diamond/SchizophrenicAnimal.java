package net.yetamine.lectures.language.inheritance.diamond;

/**
 * Demonstrates resolving conflicting default methods by overriding when the
 * inherited implementations are reused and referred with explicit qualifiers.
 */
public interface SchizophrenicAnimal extends Cat, Dog {

    default void makeSound() {
        // It is possible to refer to a particular super-interface's
        // method implementation!
        Cat.super.makeSound();
        Dog.super.makeSound();

        // Following is illegal though, even if Animal had a default
        // method implementation - only direct super-interfaces are
        // accessible through the super-interface notation.
        // Animal.super.makeSound(); // FIXME
    }
}
