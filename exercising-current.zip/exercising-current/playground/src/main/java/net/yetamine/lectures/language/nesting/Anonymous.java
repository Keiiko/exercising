package net.yetamine.lectures.language.nesting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;
import java.util.function.Supplier;

/**
 * Demonstrates a use of an anonymous class.
 */
public final class Anonymous {

    public static void main(String... args) {
        final Collection<? super Number> collection = new ArrayList<>();
        final Random random = new Random(); // Must have been final before Java 7

        // Using an anonymous class
        fill(collection, new Supplier<Integer>() {

            public Integer get() {
                return random.nextInt(10);
            }
        }, 10);

        System.out.println(collection);
    }

    public static <T> void fill(Collection<? super T> target, Supplier<? extends T> source, int count) {
        for (int i = 0; i < count; i++) {
            target.add(source.get());
        }
    }
}
