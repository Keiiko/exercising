package net.yetamine.lectures.language.inheritance.overloading;

/**
 * A dog implementation for the overloading demonstration.
 */
public class Dog {

    public String makeSound() {
        return "Woof!";
    }

    // This demonstrates overloading

    public void bark() {
        System.out.println(makeSound());
    }

    public void bark(int count) {
        for (int i = count; i > 0; i--) {
            bark();
        }
    }

    public void bark(String sound) {
        System.out.println(sound);
    }

    public void bark(String sound, int count) {
        for (int i = count; i > 0; i--) {
            bark(sound);
        }
    }
}
