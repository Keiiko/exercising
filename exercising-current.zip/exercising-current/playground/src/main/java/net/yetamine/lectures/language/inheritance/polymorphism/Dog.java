package net.yetamine.lectures.language.inheritance.polymorphism;

/**
 * Another concrete {@link Animal}.
 */
public class Dog extends Animal {

    private static final String DEFAULT_NAME = "Azor";

    public Dog() {
        this(DEFAULT_NAME);
        System.out.println("Warning: got a dog with the default name");
    }

    public Dog(String name) {
        super(name);
        System.out.println("Beware of the dog outside");
    }

    public void makeSound() {
        System.out.println("Bark!");
    }

    public void watch() {
        System.out.println("Yep, I'm watching");
    }
}
