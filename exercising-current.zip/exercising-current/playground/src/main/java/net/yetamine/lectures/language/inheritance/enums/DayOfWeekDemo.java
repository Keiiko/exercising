package net.yetamine.lectures.language.inheritance.enums;

public final class DayOfWeekDemo {

    public static void main(String... args) {
        if (DayOfWeek.valueOf("MONDAY") == DayOfWeek.MONDAY) {
            System.out.println("Oh no, again?");
        }

        for (DayOfWeek day : DayOfWeek.values()) {
            System.out.println(day);
        }

        final DayOfWeek someDay = DayOfWeek.WEDNESDAY;

        switch (someDay) {
            case MONDAY:
                System.out.println("Yawn");
                break;

            case FRIDAY:
                System.out.println("Hardly working");
                break;

            case SATURDAY:
            case SUNDAY:
                System.out.println("Relaxing");
                break;

            default:
                System.out.println("Hardworking");
        }

        System.out.println(someDay);
    }
}
