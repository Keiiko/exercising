package net.yetamine.lectures.language.exceptions;

/**
 * Demonstrates exception propagation and handling.
 */
public final class ExceptionHandling {

    public static void main(String... args) {
        try {
            System.out.println(divide(1, 0));
            System.out.println("Never printed");
        } catch (ArithmeticException e) {
            System.out.println("Caught it!");
        }

        try {
            fail();
        } catch (RuntimeException e) {
            System.out.println("Printing stacktrace:");
            e.printStackTrace(System.out);
        } finally {
            System.out.println("And finally...");
        }

        try {
            System.out.println(divide(1, 0));
            System.out.println("Never printed");
        } finally {
            System.out.println("Always printed");
        }
    }

    private static void fail() { // What if we decided to fail with IOException instead?
        throw new RuntimeException("Decided to fail.");
    }

    private static int divide(int i, int j) {
        return i / j;
    }
}
