package net.yetamine.playground;

import static net.yetamine.playground.Lambda.hasLengthOf;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class StreamExercising {
    public static void main(String... args) {
        final List<String> strings = List.of("Hello", "Dolly", "I", "Robot", "Book", "Lorem ipsum");

        // @formatter:off
        strings.stream().parallel()
                .filter(hasLengthOf(5))
                .map(String::toUpperCase)
                .sorted()
                .forEachOrdered(System.out::println);

        final List<String> result = strings.stream()
                .filter(hasLengthOf(5))
                .collect(Collectors.toCollection(ArrayList::new));
        // @formatter:on

        System.out.println(result.stream().collect(Collectors.joining(", ")));

        final Map<Integer, String> numbers = new HashMap<>();
        numbers.put(1, "one");
        numbers.put(2, "two");
        numbers.put(3, "three");
        System.out.println(numbers);
        System.out.println(numbers.get(1));
        System.out.println(numbers.keySet());
        System.out.println(numbers.values());
        for (Map.Entry<Integer, String> entry : numbers.entrySet()) {
            if (entry.getKey() % 2 == 0) {
                entry.setValue(entry.getValue() + 1);
            }
        }

        groupByLength_v3(strings).forEach((k, v) -> System.out.format("%d = %s%n", k, v));

        final List<String> lines = List.of("What do you read, my lord?", "Words, words, words.");

        System.out.println(lines.stream()
                .flatMap(line -> splitToWords(line))
                .map(String::toLowerCase)
                .collect(Collectors.groupingBy(String::length, TreeMap::new, Collectors.toSet())));
    }

    public static Stream<String> splitToWords(String line) {
        return Stream.of(line.split("[.,?; ]")).filter(s -> !s.isEmpty());
    }

    public static Map<Integer, Set<String>> groupByLength_v3(Collection<String> data) {
        return data.stream().collect(Collectors.groupingBy(String::length, TreeMap::new, Collectors.toSet()));
    }

    public static Map<Integer, Set<String>> groupByLength_v2(Collection<String> data) {
        final Map<Integer, Set<String>> result = new HashMap<>();
        data.forEach(item -> result.computeIfAbsent(item.length(), k -> new HashSet<>()).add(item));
        return result;
    }

    public static Map<Integer, Set<String>> groupByLength_v1(Collection<String> data) {
        final Map<Integer, Set<String>> result = new HashMap<>();

        data.forEach(item -> {
            final Integer length = item.length();
            Set<String> set = result.get(length);

            if (set == null) {
                set = new HashSet<>();
                result.put(length, set);
            }

            set.add(item);
        });

        return result;
    }

    public static Map<Integer, Set<String>> groupByLength_v0(Collection<String> data) {
        final Map<Integer, Set<String>> result = new HashMap<>();

        data.forEach(item -> {
            final int length = item.length();
            if (result.containsKey(length)) {
                result.get(length).add(item);
            } else {
                final Set<String> set = new HashSet<>();
                set.add(item);
                result.put(length, set);
            }
        });

        return result;
    }
}
