package net.yetamine.lectures.language.basics;

/**
 * Demonstrates argument passing with a {@link Box} as the exemplary mutable
 * instance. Because arguments in Java are passed by value,
 * {@link #swapRef(Box, Box)} can't do anything.
 */
public class ArgumentPassing {

    public static void main(String[] args) {
        Box box1 = new Box(1);
        Box box2 = new Box(2);
        System.out.format("%d, %d%n", box1.value(), box2.value());
        swapBox(box1, box2);
        System.out.format("%d, %d%n", box1.value(), box2.value());
        swapRef(box1, box2);
        System.out.format("%d, %d%n", box1.value(), box2.value());
    }

    public static void swapRef(Box box1, Box box2) {
        Box temp = box1;
        box1 = box2;
        box2 = temp;
    }

    public static void swapBox(Box box1, Box box2) {
        int temp = box1.value();
        box1.value(box2.value());
        box2.value(temp);
    }
}
