package net.yetamine.playground;

public class BigDog extends Dog {

    public BigDog(String name) {
        super(name);
    }

    public void speak() {
        for (int i = 0; i < 3; i++) {
            super.speak();
        }
    }
}
