package net.yetamine.playground;

public class Constructors {

    int value;

    public Constructors(int arg) {
        this.value = arg;
    }

    public int incrementAndGet() {
        return ++value;
    }

    public static void main(String... args) {
        Constructors oneTwoThree = new Constructors(123);
        int i = oneTwoThree.incrementAndGet();
        System.out.println(i);
        i = oneTwoThree.incrementAndGet();
        System.out.println(i);

        Constructors two = new Constructors(2);
        System.out.println(two.incrementAndGet());
        System.out.println(oneTwoThree.incrementAndGet());

        System.out.println(new Constructors(10).incrementAndGet());
    }
}
