package net.yetamine.playground;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;

public final class Lambda {
    public static void main(String... args) {
        final List<String> strings = new ArrayList<>();
        fill(strings, new ŽebříkSupplier(), 10);
        GenericMethods.printAll(strings);
//        strings.forEach(t -> System.out.println(t));
        strings.forEach(System.out::println);
        strings.removeIf(t -> t.length() == 3);
        strings.removeIf(hasLengthOf(3));

        final List<Integer> integers = new ArrayList<>();
        final int insert = 6;
        fill(integers, () -> insert, 3);
        GenericMethods.printAll(integers);
    }

    public static Predicate<String> hasLengthOf(int length) {
        return s -> s.length() == length;
    }

    public static <T> void fill(Collection<T> collection, Supplier<? extends T> supplier, int count) {
        for (int i = 0; i < count; i++) {
            collection.add(supplier.get());
        }
    }

    private static class ŽebříkSupplier implements Supplier<String> {
        public ŽebříkSupplier() {
        }

        public String get() {
            return "|-|";
        }
    }
}
