package net.yetamine.lectures.platform.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.yetamine.lectures.language.generics.Wildcards;

public final class SequenceDemo {

    public static void main(String... args) {
        final Sequence<Integer> ones = Sequence.of(1).withLength(3);
        ones.forEach(System.out::println);

        final Random randomGenerator = new Random();
        final Sequence<Integer> random = Sequence.from(() -> randomGenerator.nextInt(100)).withLength(5);
        random.forEach(System.out::println);
        System.out.println("---");
        random.withLength(10).forEach(System.out::println);

        System.out.println("---");
        final List<Integer> list = Wildcards.addAll(random, new ArrayList<>());
        System.out.println(list);
    }
}
