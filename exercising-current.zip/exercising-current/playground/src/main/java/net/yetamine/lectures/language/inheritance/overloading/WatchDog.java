package net.yetamine.lectures.language.inheritance.overloading;

/**
 * A dog with an extended behavior.
 */
public class WatchDog extends Dog {

    @Override
    public String makeSound() {
        super.makeSound(); // Using the inherited implementation
        return "Watching you!";
    }

    public void bark(int count, String sound) {
        bark(sound, count);
    }

    // Not an override, but overload!

    public void bark(Object sound, int count) {
        for (int i = count; i > 0; i--) {
            bark(String.format("(%s)", sound));
        }
    }
}
