package net.yetamine.lectures.language.basics;

/**
 * Demonstrates the tricky nature of reference equality and how it can become a
 * difficult problem when optimization techniques like instance caching step in.
 */
public class Equality {

    public static void main(String[] args) {
        int value = 123;
        Object o1 = Integer.valueOf(value);
        Object o2 = Integer.valueOf(value);
        System.out.println(o1 == o2);
    }
}
