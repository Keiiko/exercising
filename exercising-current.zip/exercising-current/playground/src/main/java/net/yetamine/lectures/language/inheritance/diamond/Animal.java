package net.yetamine.lectures.language.inheritance.diamond;

/**
 * An interface making the root of a whole hierarchy.
 */
public interface Animal {

    void makeSound();
}
