package net.yetamine.lectures.language.basics;

/**
 * Demonstrates array covariance and how it violates Liskov Substitution
 * Principle.
 */
public class ArrayCovariance {

    public static void main(String[] args) {
        String[] strings = { "A", "B" };
        Object[] objects = strings;
        objects[0] = 0;
    }
}
