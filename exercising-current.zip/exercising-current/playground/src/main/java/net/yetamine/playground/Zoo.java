package net.yetamine.playground;

public class Zoo {
    public static void main(String... args) {
        final Animal[] animals = new Animal[] {
                new Cat(),
                new Dog("Alík"),
                new BigDog("Tlapka")
            };

        for (int i = 0; i < animals.length; i++) {
            final Animal animal = animals[i];
            if (animal instanceof Named) {
                final Named named = (Named) animal;
                System.out.println(named.name());
//                System.out.println(((Named) animal).name());
            }
            animals[i].speak();
        }

        Named[] myStuff = new Named[] { new Dog() };
        for (int i = 0; i < myStuff.length; i++) {
            System.out.println(myStuff[i].name());
        }
    }
}
