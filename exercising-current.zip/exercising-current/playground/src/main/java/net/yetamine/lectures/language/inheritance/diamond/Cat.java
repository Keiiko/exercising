package net.yetamine.lectures.language.inheritance.diamond;

/**
 * An interface representing a cat.
 */
public interface Cat extends Animal {

    default void makeSound() {
        System.out.println("Miaow!");
    }

    // Here we would have more methods typical for cats
}
