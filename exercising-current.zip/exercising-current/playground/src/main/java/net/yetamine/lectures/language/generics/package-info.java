/**
 * Demonstrates making a generic class and the meaning of PECS.
 */
package net.yetamine.lectures.language.generics;
