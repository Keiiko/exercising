package net.yetamine.lectures.language.inheritance;

/**
 * Represents an entity with a name.
 */
public interface Named {

    /**
     * @return the name of the entity
     */
    String name();
}
