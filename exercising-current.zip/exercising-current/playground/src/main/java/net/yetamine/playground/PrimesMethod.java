package net.yetamine.playground;

import java.util.Arrays;

public class PrimesMethod {

    public static boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }

        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                return false;
            }
        }

        return true;
    }

    public static int[] primes(int n) {
        boolean[] numbers = new boolean[n + 1];
//        numbers[0] = true;
//        numbers[1] = true;

        int primeCount = 0;
        for (int i = 2; i <= n; i++) {
            if (!numbers[i]) {
                ++primeCount;
                for (int j = i + i; j <= n; j += i) {
                    numbers[j] = true;
                }
            }
        }

        int[] result = new int[primeCount];
        int nextIndex = 0;
        for (int i = 2; i <= n; i++) {
            if (!numbers[i]) {
                result[nextIndex++] = i;
//                result[nextIndex] = i;
//                ++nextIndex;
            }
        }

        return result;
    }

    public static void main(String... args) {
        if (isPrime(7)) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }

        System.out.println(isPrime(7) ? "Yes" : "No");

        int[] primes = primes(100);
        System.out.println(Arrays.toString(primes));
        System.out.println(primes);
    }
}
