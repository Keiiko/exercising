/**
 * Examples and samples for Stream API.
 */
package net.yetamine.lectures.platform.streams;
