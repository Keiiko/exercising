package net.yetamine.lectures.language.basics;

/**
 * A simple Hello World application.
 */
public class Hello {

    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
