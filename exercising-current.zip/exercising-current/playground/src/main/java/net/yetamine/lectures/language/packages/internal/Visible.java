package net.yetamine.lectures.language.packages.internal;

/**
 * A public class visible outside of its package.
 */
public class Visible { // Intentionally not final to be possible to abuse it

    @SuppressWarnings("unused") // Keep for playing with the accessibility
    private static int TOP_SECRET = 1234;

    public Object returnSomething() {
        return new Object();
    }

    public static void printPublic() {
        System.out.println("Internal::printPublic");
    }

    protected static void printProtected() {
        System.out.println("Internal::printProtected");
    }

    static void printPackagePrivate() {
        System.out.println("Internal::printPackagePrivate");
    }
}
