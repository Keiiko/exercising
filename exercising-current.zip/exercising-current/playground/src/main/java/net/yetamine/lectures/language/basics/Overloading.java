package net.yetamine.lectures.language.basics;

/**
 * A playground for overloading.
 */
@SuppressWarnings("unused") // To hide warnings when demonstrating
public class Overloading {

    public static void main(String[] args) {
        // TODO: Try to invoke foo() with different argument types

        foo("Hello");
        foo(1);
        foo(1L);
        foo((Integer) 1);
        foo(1, 2, 3);
        foo(1, 2, 3L);
        foo(1, 2, (short) 3);
        foo("Hello", 2, 3);
    }

    // TODO: Try to comment and uncomment some of the methods to see, how the output changes

    private static void foo(int arg) {
        System.out.println("int");
    }

    private static void foo(long arg) {
        System.out.println("long");
    }

    private static void foo(Integer arg) {
        System.out.println("Integer");
    }

    private static void foo(Long arg) {
        System.out.println("Long");
    }

    private static void foo(String arg) {
        System.out.println("String");
    }

    private static void foo(Object arg) {
        System.out.println("Object");
    }

//    private static void foo(int... arg) {
//        System.out.println("int...");
//    }

//    private static void foo(long... arg) {
//        System.out.println("int...");
//    }

    private static void foo(Integer... arg) {
        System.out.println("Integer...");
    }

    private static void foo(Object... arg) {
        System.out.println("Object...");
    }
}
