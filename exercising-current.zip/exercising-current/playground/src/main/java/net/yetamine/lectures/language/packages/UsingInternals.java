package net.yetamine.lectures.language.packages;

import net.yetamine.lectures.language.packages.internal.Internals;

/**
 * Demonstrates using the visible part of the internal package.
 */
public final class UsingInternals {

    public static void main(String... args) {
        Internals.publish();
        Internals.callHidden(true);
        Internals.callHidden(false);
    }
}
