package net.yetamine.playground;

public class Dog extends Animal implements Named {

    private final String name;

    public Dog(String name) {
        this.name = name;
    }

    public Dog() {
        this("noname");
    }

    public String name() {
        return name;
    }

    public void speak() {
        System.out.println("Woof!");
    }

    public String toString() {
        return name();
    }

    public final boolean equals(Object obj) {
        if (obj instanceof Dog) {
            final Dog o = (Dog) obj;
            return name.equals(o.name);
        }

        return false;
    }

    public final int hashCode() {
        // Objects.hash(...)
        return name.hashCode();
    }
}
