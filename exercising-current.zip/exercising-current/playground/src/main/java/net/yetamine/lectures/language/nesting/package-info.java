/**
 * Examples explaining nested types.
 */
package net.yetamine.lectures.language.nesting;
