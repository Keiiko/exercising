package net.yetamine.lectures.language.lambda;

import java.util.ArrayList;
import java.util.List;

/**
 * Shows a simple use case for lambdas.
 */
public final class Comparing {

    public static void main(String... args) {
        final List<String> strings = new ArrayList<>();
        strings.add("Hello");
        strings.add("Good bye");
        strings.add("Friday");
        strings.add("weekend");
        strings.add("Petr");

        // (string1, string2) -> int
        strings.sort(Comparing::compareStringsByLength);

        // string -> void
        strings.forEach(string -> System.out.println(string));
    }

    private static int compareStringsByLength(String string1, String string2) {
        return Integer.compare(string1.length(), string2.length());
    }
}
