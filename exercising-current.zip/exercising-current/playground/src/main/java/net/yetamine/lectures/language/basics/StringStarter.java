package net.yetamine.lectures.language.basics;

/**
 * Demonstrates common operations with strings.
 */
public class StringStarter {

    public static void main(String[] args) {
        String s = "Hello";

        // Access single characters
        for (int index = 0; index < s.length(); index++) {
            System.out.println(s.charAt(index));
        }

        // Letter case operations
        System.out.println(s.toUpperCase());

        if ("hello".equalsIgnoreCase(s)) {
            System.out.println("Yes");
        }

        // Substrings
        System.out.println(s.substring(3));
        System.out.println(s.substring(3, 4));

        // Formatting
        String givenName = "James";
        String surname = "Bond";
        String intro = String.format("Hello, my name is %s. %1$s %s.", surname, givenName);
        System.out.println(intro);

        // String building
        StringBuilder sb = new StringBuilder();
        sb.append("Hello ").append(givenName).append(", nice to meet you");
        String greeting = sb.reverse().toString();
        System.out.println(greeting);

        // Inefficient loop
        String joined = "";
        for (int number = 0; number < 500; number++) {
//            joined += number + " ";
            joined = joined + number + " ";
        }

        System.out.println(joined);

        // Efficient implementation
        sb.setLength(0);
        for (int number = 0; number < 500; number++) {
            sb.append(number).append(" ");
        }

        System.out.println(sb.toString());
    }
}
