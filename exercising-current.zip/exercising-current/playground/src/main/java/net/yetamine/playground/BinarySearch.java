package net.yetamine.playground;

import java.util.Collections;
import java.util.List;

public final class BinarySearch {
    public static void main(String... args) {
        final List<Integer> elements = List.of(1, 2, 4, 7, 8, 9);

        final int element = 5;
        final int position = Collections.binarySearch(elements, element);
        if (0 <= position) {
            System.out.println("Found, distance: 0");
        } else {
            final int insertionIndex = -(position + 1);
            if (insertionIndex == 0) {
                System.out.format("Not found, distance: %d%n", Math.abs(elements.get(insertionIndex) - element));
            } else {
                final int precedingElement = elements.get(insertionIndex - 1);
                final int succeedingElement = elements.get(insertionIndex);
                if (Math.abs(precedingElement - element) < Math.abs(succeedingElement - element)) {
                    System.out.format("Not found, distance %d, element %s%n",
                            Math.abs(precedingElement - element),
                            precedingElement);
                } else {
                    System.out.format("Not found, distance %d, element %s%n",
                            Math.abs(succeedingElement - element),
                            succeedingElement);
                }
            }
        }
    }
}
