package net.yetamine.lectures.language.packages.internal;

/**
 * A visible part of this package.
 */
public final class Internals {

    public static void publish() {
        System.out.println("Internals::published");
    }

    public static void callHidden(boolean secret) {
        if (secret) {
            secret();
            Invisible.publish();
        } else {
            internal();
        }
    }

    static void internal() {
        System.out.println("Internals::internal");
    }

    private static void secret() {
        System.out.println("Internals::secret");
    }
}
