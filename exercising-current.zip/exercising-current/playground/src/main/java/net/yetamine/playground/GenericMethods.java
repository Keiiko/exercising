package net.yetamine.playground;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class GenericMethods {

    public static <T> Set<T> singleton(T value) {
        final Set<T> result = new HashSet<>();
        result.add(value);
        return result;
    }

    public static void main(String... args) {
        final Set<Integer> anInteger = singleton(123);

        final List<Integer> integers = new ArrayList<>();
        integers.add(1);
        integers.add(2);
        integers.add(3);
//        List<Integer> unmodifiable = Collections.unmodifiableList(list);
//        unmodifiable.add(123);
        printAll(integers);

//        List<Number> numbers = Arrays.asList(1.0, 2.0, 3.0);
        List<Number> numbers = List.of(1.0, 2.0, 3.0);
        System.out.println(sum(numbers));
        System.out.println(sum(anInteger));

        final List<String> strings = new ArrayList<>();
        fill(strings, "|-|", 10);
        printAll(strings);

        fill(integers, 6, 3);
        printAll(integers);
    }

    public static <T> void fill(Collection<T> collection, T value, int count) {
        for (int i = 0; i < count; i++) {
            collection.add(value);
        }
    }

    public static double sum(Collection<? extends Number> numbers) {
        double sum = 0;
        for (Number number : numbers) {
            sum += number.doubleValue();
        }
        return sum;
    }

    public static void printAll(Iterable<?> it) {
        for (Object element : it) {
            System.out.println(element);
        }
    }
}
