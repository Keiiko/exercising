package net.yetamine.lectures.language.inheritance.diamond;

/**
 * Demonstrates resolving conflicting default methods by redeclaring the method
 * as an abstract method, which effectively removes any default implementation.
 */
public interface HybridAnimal extends Cat, Dog {

    void makeSound();
}
