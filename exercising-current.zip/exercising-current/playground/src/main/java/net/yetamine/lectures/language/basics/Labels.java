package net.yetamine.lectures.language.basics;

/**
 * Demonstrates how labels work.
 */
public class Labels {

    public static void main(String[] args) {
        int i = 10;

        label: {
            System.out.println("First message");
            if (i == 10) {
                System.out.println("Breaking");
                break label;
            }

            System.out.println("Not printed");
        }

        outer: for (int k = 0; k < 10; k++) {
            for (int l = 0; l <= k; l++) {
                if (l == 0) {
                    System.out.print("* ");
                    continue;
                }

                if (k == 5) {
                    System.out.println();
                    continue outer;
                }

                System.out.format("%d", l);
            }

            System.out.println();
        }
    }
}
