/**
 * Examples and samples for Date/Time API.
 */
package net.yetamine.lectures.platform.time;
