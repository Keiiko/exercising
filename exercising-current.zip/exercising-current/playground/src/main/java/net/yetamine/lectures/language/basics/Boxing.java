package net.yetamine.lectures.language.basics;

/**
 * Demonstrates automatic (un)boxing.
 */
public class Boxing {

    public static void main(String[] args) {
        Integer i = 10;
        int j = i;

        // The assignment crashes if we set i to null
        // i = null;
        j = i;
        System.out.println(j);

        // Type conversions do not work for boxed primitives.
        // Class casting is a different mechanism.
        Double d = (Double) (Object) i;
        System.out.println(d);
    }
}
