package net.yetamine.lectures.language.generics;

import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Polished and improved implementation of the box concept, including a few bits
 * of support for standard functional interfaces (but lacking proper public
 * documentation).
 *
 * @param <T>
 *            the type of the boxed value
 */
public final class Box<T> implements Supplier<T> {

    private T data;

    /**
     * Creates a new instance containing {@code null}.
     */
    public Box() {
        // Default constructor
    }

    public Box(T value) {
        data = value;
    }

    // It is often a good idea to provide an alternative to constructor
    // and possibly even hide the constructor. Not done in this case,
    // we could consider it.

    public static <T> Box<T> of(T value) {
        return new Box<>(value);
    }

    @Override
    public String toString() {
        return String.format("Box[%s]", data);
    }

    @Override
    public boolean equals(Object obj) {
        return (obj instanceof Box) && Objects.equals(data, ((Box<?>) obj).data);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(data);
    }

    public T get() {
        return data;
    }

    // See enabling the fluent style by returning this instance often
    // where void return type would be used otherwise. This allows
    // chaining the calls and often more compact and readable code.

    public Box<T> set(T value) {
        data = value;
        return this;
    }

    public T exchange(T value) {
        final T result = data;
        data = value;
        return result;
    }

    public Box<T> addTo(Collection<? super T> collection) { // Example for contravariance
        collection.add(data);
        return this;
    }

    public Box<T> takeFrom(Collection<? extends T> collection) { // Example for covariance
        // Failure-atomic implementation: either fails, or succeeds completely
        final Iterator<? extends T> iterator = collection.iterator();
        final T value = iterator.next();
        iterator.remove();
        data = value;
        return this;
    }

    public Box<T> swap(Box<T> box) { // Example for invariance
        return set(box.exchange(data));
    }

    public <R> Box<R> map(Function<? super T, ? extends R> mapping) { // Typical mapping wildcards and method-local type parameter
        return of(mapping.apply(data));
    }
}
