package net.yetamine.playground;

import java.io.IOException;
import java.util.Scanner;

public class Exceptions {
    private static void fail() throws IOException {
        try (Scanner scanner = new Scanner(System.in)) {
//        ((Object) null).toString();
            final int number = scanner.nextInt();
            final int divisor = scanner.nextInt();
            System.out.println(number / divisor);
            // throw new IOException();
        } finally {
            System.out.println("Fail always succeeds");
        }
    }

    public static void main(String... args) {
        try {
            fail();
        } catch (ArithmeticException e) {
            System.out.println("Computation failed.");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println("Always printed");
        }

        System.out.println("Exception handled");
    }
}
