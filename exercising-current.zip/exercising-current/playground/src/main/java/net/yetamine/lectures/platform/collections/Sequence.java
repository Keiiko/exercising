package net.yetamine.lectures.platform.collections;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Provides a sequence with the given length of values provided by a
 * {@link Supplier}, so that it can be used for producing a constant or random
 * sequence easily.
 *
 * @param <T>
 *            the type of the elements
 */
public final class Sequence<T> implements Iterable<T> {

    private final Supplier<T> source;
    private final int length;

    @SuppressWarnings("unchecked") // Cast to Supplier<T>
    private Sequence(Supplier<? extends T> supplier, int count) {
        assert (supplier != null);
        source = (Supplier<T>) supplier;
        length = count;
    }

    public static <T> Sequence<T> of(T element) {
        return from(() -> element);
    }

    public static <T> Sequence<T> from(Supplier<? extends T> supplier) {
        return new Sequence<>(supplier, 0);
    }

    @Override
    public String toString() {
        // Could be upgraded to use streams:
        // return stream().collect(Collectors.joining(", ", "[", "]"));

        final StringJoiner result = new StringJoiner(", ", "[", "]");

        for (T item : this) {
            result.add(Objects.toString(item));
        }

        return result.toString();
    }

    public Sequence<T> withLength(int count) {
        if (count < 0) {
            throw new IllegalArgumentException(String.format("Invalid length given: %d.", count));
        }

        if (count == length) { // Natural optimization for immutable classes
            return this;
        }

        return new Sequence<>(source, count);
    }

    public Iterator<T> iterator() {
        return new Iterator<T>() {

            private int count = length;

            public boolean hasNext() {
                return (count > 0);
            }

            public T next() {
                if (hasNext()) {
                    --count;
                    return source.get();
                }

                throw new NoSuchElementException();
            }
        };
    }

    public Stream<T> stream() {
        return Stream.generate(source).limit(length);
    }
}
